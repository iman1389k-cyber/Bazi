# Color Memory Game

## Overview

This is a full-stack web application built with a React frontend and Express.js backend, featuring a vanilla JavaScript color memory game as the main component. The game challenges players to memorize and repeat sequences of colored circles with progressive difficulty levels. The application uses a modern tech stack with TypeScript, Tailwind CSS, and shadcn/ui components for a polished user interface.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development and building
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent design
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management and React hooks for local state
- **Game Implementation**: Vanilla JavaScript for the core memory game logic (located in `client/src/script.js`)

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Development**: tsx for running TypeScript files in development
- **Build System**: esbuild for production bundling with external package handling

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Local Storage**: Browser localStorage for game high scores and preferences
- **Session Management**: connect-pg-simple for PostgreSQL-backed sessions

### Database Schema
- **Users Table**: Basic user management with id, username, and password fields
- **Migrations**: Managed through Drizzle Kit with schema definitions in `shared/schema.ts`

### Authentication and Authorization
- **Strategy**: Session-based authentication using PostgreSQL sessions
- **Password Security**: Basic password hashing (implementation in user storage interface)
- **User Management**: CRUD operations through storage abstraction layer

### UI Component System
- **Design System**: shadcn/ui components with Radix UI primitives
- **Theming**: CSS custom properties with light/dark mode support
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Accessibility**: ARIA labels, keyboard navigation, and screen reader support

### Game Features
- **Difficulty Levels**: Easy, Normal, and Hard modes with different speeds and scoring
- **Accessibility**: Color-blind mode with pattern overlays, keyboard controls
- **Audio**: Web Audio API for sound effects with toggle option
- **Persistence**: High scores saved to localStorage
- **Progressive Difficulty**: Increasing sequence length and speed as levels advance

### Development Environment
- **Hot Reload**: Vite dev server with HMR for React components
- **Error Handling**: Runtime error overlay for development
- **Type Safety**: Strict TypeScript configuration with path aliases
- **Code Quality**: ESLint and TypeScript compiler checks

## External Dependencies

### Core Framework Dependencies
- **@vitejs/plugin-react**: React support for Vite build system
- **express**: Web application framework for Node.js server
- **drizzle-orm**: Type-safe ORM for PostgreSQL database operations
- **@neondatabase/serverless**: Serverless PostgreSQL client for Neon database

### UI and Styling
- **@radix-ui/react-***: Comprehensive set of unstyled, accessible UI primitives
- **tailwindcss**: Utility-first CSS framework for responsive design
- **class-variance-authority**: Utility for creating variant-based component APIs
- **clsx**: Utility for constructing className strings conditionally

### State Management and Data Fetching
- **@tanstack/react-query**: Powerful data synchronization for React applications
- **wouter**: Minimalist routing library for React

### Form Handling and Validation
- **react-hook-form**: Performant forms with easy validation
- **@hookform/resolvers**: Validation resolvers for react-hook-form
- **zod**: TypeScript-first schema validation (via drizzle-zod)

### Development Tools
- **tsx**: TypeScript execution environment for Node.js
- **esbuild**: Fast JavaScript bundler for production builds
- **drizzle-kit**: CLI companion for Drizzle ORM schema management
- **@replit/vite-plugin-runtime-error-modal**: Development error reporting
- **@replit/vite-plugin-cartographer**: Development tooling for Replit environment

### Utility Libraries
- **date-fns**: Modern JavaScript date utility library
- **nanoid**: URL-safe unique string ID generator
- **cmdk**: Command palette component for search interfaces
- **embla-carousel-react**: Carousel component for React applications