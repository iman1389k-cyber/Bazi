// Color Memory Game - Single Display Version
// A responsive memory game with a single display location for colors

// Game state management
let gameState = {
    isPlaying: false,
    isPaused: false,
    isShowingSequence: false,
    sequence: [],
    userInput: [],
    stage: 1,
    score: 0,
    bestScore: 0,
    difficulty: 'normal',
    colorBlindMode: false,
    soundEnabled: true,
    currentSequenceIndex: 0,
    buttonPositions: []
};

// Difficulty settings with longer display times
const difficultySettings = {
    easy: { startLength: 3, displayTime: 1500, delay: 500, multiplier: 1 },
    normal: { startLength: 4, displayTime: 1200, delay: 400, multiplier: 1.5 },
    hard: { startLength: 5, displayTime: 1000, delay: 300, multiplier: 2 }
};

// Game colors array for reference
const gameColors = ['red', 'blue', 'green', 'yellow', 'purple', 'orange'];

// Timeout storage for cleanup
let timers = [];
let audioContext = null;

// Initialize game on page load
document.addEventListener('DOMContentLoaded', function() {
    initGame();
});

/**
 * Initialize the game - set up event listeners and load saved data
 */
function initGame() {
    console.log('Initializing Color Memory Game - Single Display Version...');
    
    // Initialize Web Audio Context for sounds
    try {
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) {
        console.log('Web Audio API not supported, sounds will be disabled');
        gameState.soundEnabled = false;
        updateSoundToggle();
    }
    
    // Load best score from localStorage
    loadBestScore();
    
    // Set up event listeners
    setupEventListeners();
    
    // Initialize UI state
    updateGameStatus('Ready to start - Click Start Game!', 'ready');
    updateHUD();
    
    console.log('Game initialized successfully');
}

/**
 * Load best score from localStorage
 */
function loadBestScore() {
    const savedBest = localStorage.getItem('cm_highscore_v1');
    if (savedBest) {
        gameState.bestScore = parseInt(savedBest, 10);
        console.log(`Loaded best score: ${gameState.bestScore}`);
    }
}

/**
 * Set up all event listeners
 */
function setupEventListeners() {
    // Game control buttons
    document.getElementById('startBtn').addEventListener('click', startGame);
    document.getElementById('pauseBtn').addEventListener('click', pauseGame);
    document.getElementById('resumeBtn').addEventListener('click', resumeGame);
    document.getElementById('playAgainBtn').addEventListener('click', startGame);
    document.getElementById('closeModalBtn').addEventListener('click', closeModal);
    
    // Settings toggles and controls
    document.getElementById('cbToggle').addEventListener('click', toggleColorBlindMode);
    document.getElementById('soundToggle').addEventListener('click', toggleSound);
    document.getElementById('difficulty').addEventListener('change', changeDifficulty);
    document.getElementById('resetHighScore').addEventListener('click', resetHighScore);

    // Game board buttons
    const gameButtons = document.querySelectorAll('.game-button');
    gameButtons.forEach((button, index) => {
        button.addEventListener('click', () => handleUserInput(index));
    });

    // Keyboard support
    document.addEventListener('keydown', handleKeyPress);
    
    // Modal click outside to close
    document.getElementById('gameOverModal').addEventListener('click', (e) => {
        if (e.target === e.currentTarget) {
            closeModal();
        }
    });
    
    console.log('Event listeners set up');
}

/**
 * Start a new game
 */
function startGame() {
    console.log(`Starting new game on ${gameState.difficulty} difficulty`);
    
    // Reset game state
    gameState.isPlaying = true;
    gameState.isPaused = false;
    gameState.isShowingSequence = false;
    gameState.sequence = [];
    gameState.userInput = [];
    gameState.stage = 1;
    gameState.score = 0;
    gameState.currentSequenceIndex = 0;
    
    // Clean up any existing timers
    cleanupTimers();
    
    // Hide selection buttons and show color display
    hideSelectionButtons();
    showColorDisplay();
    
    // Update UI
    updateHUD();
    updateGameStatus('Starting game...', 'playing');
    updateButtonVisibility('playing');
    closeModal();
    
    // Resume audio context if needed (user interaction requirement)
    if (audioContext && audioContext.state === 'suspended') {
        audioContext.resume();
    }
    
    // Start first level
    setTimeout(() => {
        nextStage();
    }, 1000);
}

/**
 * Pause the current game
 */
function pauseGame() {
    if (!gameState.isPlaying || gameState.isPaused) return;
    
    console.log('Game paused');
    gameState.isPaused = true;
    cleanupTimers();
    
    updateGameStatus('Game paused', 'paused');
    updateButtonVisibility('paused');
}

/**
 * Resume the paused game
 */
function resumeGame() {
    if (!gameState.isPlaying || !gameState.isPaused) return;
    
    console.log('Game resumed');
    gameState.isPaused = false;
    
    updateGameStatus('Game resumed - watch the sequence!', 'playing');
    updateButtonVisibility('playing');
    
    // Continue showing sequence if we were in the middle of one
    if (gameState.isShowingSequence) {
        continueShowingSequence();
    }
}

/**
 * Handle user input on color buttons
 */
function handleUserInput(colorIndex) {
    // Don't accept input during sequence display, pause, or game not playing
    if (!gameState.isPlaying || gameState.isPaused || gameState.isShowingSequence) {
        return;
    }
    
    // Get the actual color index from the randomized button positions
    const actualColorIndex = gameState.buttonPositions[colorIndex];
    
    console.log(`User selected button ${colorIndex} which is color ${actualColorIndex} (${gameColors[actualColorIndex]})`);
    
    // Play sound feedback
    if (gameState.soundEnabled) {
        playColorSound(actualColorIndex);
    }
    
    // Add visual feedback
    highlightButton(colorIndex, 200);
    
    // Check if input matches sequence
    const currentStep = gameState.userInput.length;
    const expectedColor = gameState.sequence[currentStep];
    
    if (actualColorIndex === expectedColor) {
        // Correct input
        gameState.userInput.push(actualColorIndex);
        console.log(`Correct! Progress: ${gameState.userInput.length}/${gameState.sequence.length}`);
        
        // Check if sequence is complete
        if (gameState.userInput.length === gameState.sequence.length) {
            // Level completed!
            const points = calculateScore();
            gameState.score += points;
            
            updateGameStatus(`Level ${gameState.stage} completed! +${points} points`, 'playing');
            updateHUD();
            
            // Hide selection buttons
            hideSelectionButtons();
            
            // Move to next stage after a brief delay
            setTimeout(() => {
                nextStage();
            }, 1500);
        } else {
            // Continue with current sequence
            updateGameStatus(`Good! ${gameState.sequence.length - gameState.userInput.length} more to go...`, 'playing');
        }
    } else {
        // Wrong input - game over
        console.log(`Wrong input! Expected ${expectedColor} (${gameColors[expectedColor]}), got ${actualColorIndex} (${gameColors[actualColorIndex]})`);
        
        // Show error animation
        const button = document.querySelectorAll('.game-button')[colorIndex];
        button.classList.add('error');
        setTimeout(() => button.classList.remove('error'), 500);
        
        gameOver();
    }
}

/**
 * Move to the next stage/level
 */
function nextStage() {
    if (!gameState.isPlaying || gameState.isPaused) return;
    
    gameState.stage++;
    gameState.userInput = [];
    
    // Generate next color in sequence
    const newColor = generateNextColor();
    gameState.sequence.push(newColor);
    
    console.log(`Level ${gameState.stage}: Sequence length ${gameState.sequence.length}`);
    console.log('Current sequence:', gameState.sequence.map(i => gameColors[i]));
    
    updateHUD();
    updateGameStatus(`Level ${gameState.stage} - Watch the sequence...`, 'playing');
    
    // Show the sequence after a brief delay
    setTimeout(() => {
        showSequence();
    }, 1000);
}

/**
 * Generate a random color index for the sequence
 */
function generateNextColor() {
    return Math.floor(Math.random() * 6);
}

/**
 * Display the current sequence to the player in the color display circle
 */
function showSequence() {
    if (!gameState.isPlaying || gameState.isPaused) return;
    
    gameState.isShowingSequence = true;
    gameState.currentSequenceIndex = 0;
    
    updateGameStatus('Watch carefully...', 'playing');
    
    continueShowingSequence();
}

/**
 * Continue showing sequence from current index (used for resume)
 */
function continueShowingSequence() {
    if (!gameState.isPlaying || gameState.isPaused || !gameState.isShowingSequence) return;
    
    const settings = difficultySettings[gameState.difficulty];
    
    if (gameState.currentSequenceIndex < gameState.sequence.length) {
        const colorIndex = gameState.sequence[gameState.currentSequenceIndex];
        
        console.log(`Showing color ${gameState.currentSequenceIndex + 1}/${gameState.sequence.length}: ${gameColors[colorIndex]}`);
        
        // Display the color in the central circle
        displayColorInCircle(colorIndex, settings.displayTime);
        
        // Play sound if enabled
        if (gameState.soundEnabled) {
            playColorSound(colorIndex);
        }
        
        gameState.currentSequenceIndex++;
        
        // Schedule next color or end sequence
        const timer = setTimeout(() => {
            continueShowingSequence();
        }, settings.displayTime + settings.delay);
        
        timers.push(timer);
    } else {
        // Sequence complete - show selection buttons
        gameState.isShowingSequence = false;
        hideColorDisplay();
        showSelectionButtons();
        updateGameStatus('Your turn! Repeat the sequence.', 'playing');
        
        console.log('Sequence display complete - waiting for user input');
    }
}

/**
 * Display a color in the central display circle
 */
function displayColorInCircle(colorIndex, duration) {
    const colorDisplay = document.getElementById('colorDisplay');
    const colorClass = `game-color-${colorIndex}`;
    
    // Set the color and show animation
    colorDisplay.className = `color-display ${colorClass}`;
    colorDisplay.classList.add('showing');
    
    // Remove animation class after duration
    const timer = setTimeout(() => {
        colorDisplay.classList.remove('showing');
    }, duration);
    
    timers.push(timer);
}

/**
 * Show the color display circle
 */
function showColorDisplay() {
    const colorDisplay = document.getElementById('colorDisplay');
    colorDisplay.classList.remove('hidden', 'fade-out');
}

/**
 * Hide the color display circle
 */
function hideColorDisplay() {
    const colorDisplay = document.getElementById('colorDisplay');
    colorDisplay.classList.add('fade-out');
    
    // Completely hide after animation
    setTimeout(() => {
        colorDisplay.classList.add('hidden');
        colorDisplay.className = 'color-display hidden';
    }, 300);
}

/**
 * Show selection buttons with randomized positions
 */
function showSelectionButtons() {
    const gameBoard = document.getElementById('gameBoard');
    const buttons = document.querySelectorAll('.game-button');
    
    // Randomize button positions
    gameState.buttonPositions = shuffleArray([0, 1, 2, 3, 4, 5]);
    
    // Apply randomized colors to buttons
    buttons.forEach((button, index) => {
        const colorIndex = gameState.buttonPositions[index];
        button.className = `game-button game-color-${colorIndex}`;
        button.setAttribute('data-color', colorIndex);
        button.setAttribute('aria-label', `${gameColors[colorIndex]} circle, button ${index + 1}`);
        button.disabled = false;
    });
    
    // Show the game board with fade-in animation
    gameBoard.classList.remove('hidden');
    setTimeout(() => {
        gameBoard.classList.add('fade-in');
    }, 50);
    
    console.log('Button positions:', gameState.buttonPositions.map(i => gameColors[i]));
}

/**
 * Hide selection buttons
 */
function hideSelectionButtons() {
    const gameBoard = document.getElementById('gameBoard');
    gameBoard.classList.remove('fade-in');
    
    setTimeout(() => {
        gameBoard.classList.add('hidden');
    }, 400);
}

/**
 * Shuffle an array (Fisher-Yates algorithm)
 */
function shuffleArray(array) {
    const shuffled = [...array];
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}

/**
 * Highlight a game button with animation
 */
function highlightButton(buttonIndex, duration) {
    const button = document.querySelectorAll('.game-button')[buttonIndex];
    if (!button) return;
    
    button.classList.add('highlighting');
    
    const timer = setTimeout(() => {
        button.classList.remove('highlighting');
    }, duration);
    
    timers.push(timer);
}

/**
 * Calculate score for completing current level
 */
function calculateScore() {
    const settings = difficultySettings[gameState.difficulty];
    const basePoints = gameState.sequence.length * Math.floor(settings.multiplier);
    
    // Bonus for consecutive levels (combo system)
    const comboBonus = gameState.stage > 3 && gameState.stage % 3 === 0 ? Math.floor(basePoints * 0.5) : 0;
    
    return basePoints + comboBonus;
}

/**
 * End the game
 */
function gameOver() {
    console.log(`Game Over! Final score: ${gameState.score}, Level reached: ${gameState.stage}`);
    
    gameState.isPlaying = false;
    gameState.isPaused = false;
    cleanupTimers();
    
    // Hide all game elements
    hideColorDisplay();
    hideSelectionButtons();
    
    // Check for new best score
    const isNewBest = gameState.score > gameState.bestScore;
    if (isNewBest) {
        gameState.bestScore = gameState.score;
        saveBestScore();
        console.log('New best score achieved!');
    }
    
    // Update modal content
    updateGameOverModal(isNewBest);
    
    // Show modal
    showGameOverModal();
    
    // Reset button visibility
    updateButtonVisibility('gameover');
    updateGameStatus('Game Over! Click Start Game to play again.', 'gameover');
    updateHUD();
}

/**
 * Update game over modal content
 */
function updateGameOverModal(isNewBest) {
    document.getElementById('finalScore').textContent = gameState.score;
    document.getElementById('finalLevel').textContent = gameState.stage - 1; // Stage is incremented before sequence, so subtract 1
    
    const newBestElement = document.getElementById('newBestScore');
    if (isNewBest) {
        newBestElement.classList.remove('hidden');
    } else {
        newBestElement.classList.add('hidden');
    }
}

/**
 * Show game over modal
 */
function showGameOverModal() {
    const modal = document.getElementById('gameOverModal');
    modal.classList.remove('hidden');
    
    // Focus the play again button for accessibility
    setTimeout(() => {
        document.getElementById('playAgainBtn').focus();
    }, 300);
}

/**
 * Close game over modal
 */
function closeModal() {
    const modal = document.getElementById('gameOverModal');
    modal.classList.add('hidden');
}

/**
 * Save best score to localStorage
 */
function saveBestScore() {
    localStorage.setItem('cm_highscore_v1', gameState.bestScore.toString());
    console.log(`Best score saved: ${gameState.bestScore}`);
}

/**
 * Toggle color-blind mode
 */
function toggleColorBlindMode() {
    gameState.colorBlindMode = !gameState.colorBlindMode;
    const button = document.getElementById('cbToggle');
    const gameBoard = document.getElementById('gameBoard');
    
    console.log(`Color-blind mode: ${gameState.colorBlindMode ? 'enabled' : 'disabled'}`);
    
    if (gameState.colorBlindMode) {
        gameBoard.classList.add('colorblind-mode');
        button.setAttribute('aria-pressed', 'true');
        button.classList.add('active');
    } else {
        gameBoard.classList.remove('colorblind-mode');
        button.setAttribute('aria-pressed', 'false');
        button.classList.remove('active');
    }
    
    updateGameStatus(`Color-blind mode ${gameState.colorBlindMode ? 'enabled' : 'disabled'}`, gameState.isPlaying ? 'playing' : 'ready');
}

/**
 * Toggle sound on/off
 */
function toggleSound() {
    gameState.soundEnabled = !gameState.soundEnabled;
    updateSoundToggle();
    
    console.log(`Sound: ${gameState.soundEnabled ? 'enabled' : 'disabled'}`);
    updateGameStatus(`Sound ${gameState.soundEnabled ? 'enabled' : 'disabled'}`, gameState.isPlaying ? 'playing' : 'ready');
}

/**
 * Update sound toggle button appearance
 */
function updateSoundToggle() {
    const button = document.getElementById('soundToggle');
    const icon = button.querySelector('.sound-icon');
    
    if (gameState.soundEnabled && audioContext) {
        button.setAttribute('aria-pressed', 'true');
        button.classList.add('active');
        icon.textContent = '🔊';
    } else {
        button.setAttribute('aria-pressed', 'false');
        button.classList.remove('active');
        icon.textContent = '🔇';
    }
}

/**
 * Change difficulty level
 */
function changeDifficulty(event) {
    gameState.difficulty = event.target.value;
    console.log(`Difficulty changed to: ${gameState.difficulty}`);
    updateGameStatus(`Difficulty set to ${gameState.difficulty}`, gameState.isPlaying ? 'playing' : 'ready');
}

/**
 * Reset high score
 */
function resetHighScore() {
    const confirmed = confirm('Are you sure you want to reset your high score? This action cannot be undone.');
    if (confirmed) {
        gameState.bestScore = 0;
        localStorage.removeItem('cm_highscore_v1');
        updateHUD();
        updateGameStatus('High score reset!', 'ready');
        console.log('High score reset by user');
    }
}

/**
 * Handle keyboard input
 */
function handleKeyPress(event) {
    // Color selection keys (1-6 for buttons, QWE/ASD for buttons)
    const keyMap = {
        '1': 0, '2': 1, '3': 2, '4': 3, '5': 4, '6': 5,
        'q': 0, 'w': 1, 'e': 2, 'a': 3, 's': 4, 'd': 5
    };
    
    const buttonIndex = keyMap[event.key.toLowerCase()];
    if (buttonIndex !== undefined) {
        event.preventDefault();
        handleUserInput(buttonIndex);
        return;
    }
    
    // Game control keys
    switch (event.key) {
        case ' ':
        case 'Enter':
            event.preventDefault();
            if (!gameState.isPlaying) {
                startGame();
            } else if (gameState.isPaused) {
                resumeGame();
            } else {
                pauseGame();
            }
            break;
            
        case 'Escape':
            event.preventDefault();
            if (gameState.isPlaying && !gameState.isPaused) {
                pauseGame();
            } else if (document.getElementById('gameOverModal').classList.contains('hidden') === false) {
                closeModal();
            }
            break;
    }
}

/**
 * Play sound for a specific color using Web Audio API
 */
function playColorSound(colorIndex) {
    if (!gameState.soundEnabled || !audioContext) return;
    
    try {
        // Create oscillator for beep sound
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        
        // Connect audio nodes
        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        // Set frequency based on color (different tones for each color)
        const frequencies = [261.63, 293.66, 329.63, 349.23, 392.00, 440.00]; // C4, D4, E4, F4, G4, A4
        oscillator.frequency.setValueAtTime(frequencies[colorIndex], audioContext.currentTime);
        
        // Set volume envelope
        gainNode.gain.setValueAtTime(0, audioContext.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.1, audioContext.currentTime + 0.01);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.2);
        
        // Play the sound
        oscillator.start(audioContext.currentTime);
        oscillator.stop(audioContext.currentTime + 0.2);
        
    } catch (error) {
        console.log('Error playing sound:', error);
    }
}

/**
 * Update button visibility based on game state
 */
function updateButtonVisibility(state) {
    const startBtn = document.getElementById('startBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    const resumeBtn = document.getElementById('resumeBtn');
    
    // Hide all first
    startBtn.classList.add('hidden');
    pauseBtn.classList.add('hidden');
    resumeBtn.classList.add('hidden');
    
    // Enable/disable based on state
    pauseBtn.disabled = false;
    resumeBtn.disabled = false;
    
    switch (state) {
        case 'playing':
            pauseBtn.classList.remove('hidden');
            break;
        case 'paused':
            resumeBtn.classList.remove('hidden');
            break;
        case 'gameover':
        default:
            startBtn.classList.remove('hidden');
            break;
    }
}

/**
 * Update HUD display
 */
function updateHUD() {
    document.getElementById('stage').textContent = gameState.stage;
    document.getElementById('score').textContent = gameState.score;
    document.getElementById('best').textContent = gameState.bestScore;
}

/**
 * Update game status display
 */
function updateGameStatus(message, status) {
    const statusElement = document.getElementById('gameStatus');
    const indicatorElement = document.getElementById('statusIndicator');
    
    statusElement.textContent = message;
    
    // Update status indicator color
    indicatorElement.className = `status-indicator status-${status}`;
    
    console.log(`Status: ${message}`);
}

/**
 * Clean up all active timers to prevent memory leaks
 */
function cleanupTimers() {
    timers.forEach(timer => clearTimeout(timer));
    timers = [];
    console.log('Timers cleaned up');
}

// Cleanup timers when page is unloaded
window.addEventListener('beforeunload', cleanupTimers);

// Handle visibility change (pause when tab is hidden)
document.addEventListener('visibilitychange', function() {
    if (document.hidden && gameState.isPlaying && !gameState.isPaused) {
        console.log('Page hidden - auto-pausing game');
        pauseGame();
    }
});

console.log('Color Memory Game - Single Display Version script loaded successfully');